<?php

$base = "http://localhost/mentopace/";

if(session_status() === PHP_SESSION_NONE) session_start();
//import functions
require 'functions.php';

?>