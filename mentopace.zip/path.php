<?php
//include app
require('core/app.php');
//check if user is logged in already
if(isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])){
    header("Location: ./dashboard");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://unpkg.com/octavalidate@latest/native/validate.js"></script>
    <?php include('includes/head.php'); ?>
    <link rel="stylesheet" href="assets/css/auth.css">
    <title>Choose your path</title>
</head>

<body>
    <main>
        <?php include('includes/navbar.php'); ?>
        <div class="whole p-4">
            <section>
                <h3 class="text-center">Choose your path</h3>
                <h6 class="text-center subtitle">Choose a path that is right for you</h6>
                <article class="p-3">
                    <a href="mentee/register" class="btn btn-outline-danger mb-2">I am a Mentee <i class="fas fa-arrow-right"></i></a>
                    <a href="mentor/register" class="btn btn-danger">I am a Mentor <i class="fas fa-arrow-right"></i></a>
                </article>
            </section>
            </form>
        </div>
    </main>
    <?php include 'includes/foot.php'; ?>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        $('#form_login').on('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const btn = e.target.querySelector('button[form="form_login"');
            //add token
            formData.append('token', '');
            const myForm = new octaValidate('form_login', {
                errorElem: {
                    "inp_pass": "merge"
                }
            });
            if (myForm.validate()) {
                btn.setAttribute("disabled", "disabled");
                //send request
                fetch('api/login.php', {
                        mode: "cors",
                        method: "post",
                        body: formData
                    })
                    .then(res => res.json())
                    .then(res => {
                        if (res.success) {
                            toastr.success(res.data.message);
                            setTimeout(() => {
                                window.location.href('dashboard');
                            }, 5000)
                        } else {
                            toastr.error(res.data.message)
                        }
                        btn.removeAttribute("disabled");
                    })
                    .catch(err => {
                        console.log(err);
                        btn.removeAttribute("disabled");
                    })
            }
        })
    })
    </script>
</body>

</html>